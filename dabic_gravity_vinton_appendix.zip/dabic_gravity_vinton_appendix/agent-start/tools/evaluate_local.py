#!/usr/bin/env python3
"""Local wrapper for evaluating a DABIC submission outputs directory.

Usage:
    python agent-start/tools/evaluate_local.py /path/to/outputs
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path


def main() -> int:
    outputs = Path(sys.argv[1] if len(sys.argv) > 1 else "outputs").resolve()
    root = Path(__file__).resolve().parents[2]
    evaluator = root / "scorer" / "evaluate.py"
    if not evaluator.exists():
        print(f"missing evaluator: {evaluator}", file=sys.stderr)
        return 2
    if not outputs.exists():
        print(f"missing outputs directory: {outputs}", file=sys.stderr)
        return 2
    return subprocess.call([sys.executable, str(evaluator), str(outputs)])


if __name__ == "__main__":
    raise SystemExit(main())
