#!/usr/bin/env bash
set -euo pipefail

SUBMISSION_DIR="${1:-/home/workspace/dabic_gravity_vinton/outputs}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

PYTHONPATH="${SCRIPT_DIR}:${PYTHONPATH:-}" python "${SCRIPT_DIR}/evaluate.py" "${SUBMISSION_DIR}"
