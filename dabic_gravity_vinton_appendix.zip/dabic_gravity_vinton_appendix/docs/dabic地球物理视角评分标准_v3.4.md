# DABIC 重力反演任务评分标准：地球物理评审视角 v3.4

## 1. 评分目标

本评分标准面向 D-ABIC gravity inversion 任务。它评价的不是单纯的代码完整性，而是一个 agent 是否真正实现了可迁移的地球物理反演流程：

1. 能否把 D-ABIC beta 估计作为 SimPEG inversion directive 接入反演循环。
2. 能否在合成重力异常数据上恢复合理的地下密度异常体。
3. 能否在未公开 hidden scenarios 上表现出泛化能力。
4. 能否在 Vinton dome 实测重力数据上给出地质上合理的解释。
5. 能否避免把 D-ABIC 退化成 cooling beta、target misfit 或 chi-square 后处理。
6. 能否用稳定的数据空间 log-determinant 近似，而不是在病态大矩阵上直接计算 determinant。

当前校准目标是：

```text
30min agent <= 15
2h agent > 30min
2h agent <= 30
```

这个目标反映了题目难度判断：该任务属于科研型地球物理工程题，30 分钟内可以跑通浅层框架，但不应获得高分；2 小时应能改进 hidden/Vinton/report，但若仍有结构性缺陷，也不应超过 30 分。

## 2. 总分结构

总分为 100 分：

| 组件 | 分数 | 地球物理含义 |
|---|---:|---|
| A 静态扫描 | 3 | 是否有基本 D-ABIC 实现痕迹，例如数据空间、log search、稳定 logdet |
| B 合成验证 | 12 | 在公开合成模型上是否能恢复密度异常、拟合噪声水平并优于 cooling |
| C hidden 泛化 | 35 | 在未公开重力反演场景中是否有真实泛化能力 |
| D Vinton 实测 | 30 | 在 Vinton dome 实测重力数据上是否恢复合理 cap rock / salt dome 结构 |
| E 行为指纹 | 8 | D-ABIC 机制是否真实：beta 更新、数据空间、logdet、L0/L1 响应 |
| F 报告 | 12 | 是否能用地球物理语言解释方法、结果、局限和迁移关系 |

最终分数：

```text
raw_total = A + B + C + D + E + F
final_score = raw_total * structural_penalty
```

## 3. A：静态扫描，3 分

A 是轻量代码审查，不直接证明结果正确，只判断是否存在 D-ABIC 的基本实现结构。

| 指标 | 分数 | 评审解释 |
|---|---:|---|
| 避免 `np.linalg.det` | 1 | 直接 determinant 对重力反演 Hessian / covariance 矩阵不稳定 |
| 数据空间结构 + beta 寻优证据 | 1 | D-ABIC 应优先在 `n_data x n_data` 空间处理 evidence 项 |
| log search + regularization Hessian 证据 | 1 | beta 应在 log 尺度或 evidence 目标下寻优，并考虑正则项曲率 |

A 分数低说明实现可能只是普通 inversion wrapper；A 分数高也不代表反演有效，只说明具备基本代码形态。

## 4. B：合成验证，12 分

B 读取 `results.json` 中的 `synthetic_L0` 和 `synthetic_L1`。L0、L1 各 6 分。

每个 norm 的 6 分由四类指标组成：

| 指标 | 分数 | 地球物理意义 |
|---|---:|---|
| `chi2_per_N` | 1.5 | 数据拟合是否接近观测噪声水平 |
| DABIC RMSE 相对 cooling RMSE | 2.5 | D-ABIC 是否优于常规 cooling beta |
| beta history 收敛 | 1.0 | beta 是否在反演中真实更新 |
| body IoU | 1.0 | 恢复异常体支撑是否接近合成真值 |

合理行为：

```text
chi2_per_N ≈ 1
RMSE_DABIC < RMSE_cooling
beta_history 有多步更新
恢复体位置和尺度与真值有明显重叠
```

不合理行为：

```text
只拟合数据但模型支撑错误
只恢复公开椭球/块体形状
beta 固定或只做 cooling
chi2 后处理替代 ABIC evidence
```

## 5. C：hidden 泛化，35 分

C 是本题最重要的能力评价之一。它不看公开 Vinton 数据，而是构造未公开的 3D gravity hidden scenarios。

v3.4 中，C 被设计为：

| 子项 | 分数 | 目标 |
|---|---:|---|
| C1 smoke test | 4 | 最小 hidden SimPEG case 是否能跑 |
| C2 hidden smoke 运行质量 | 4 | L0/L1 smoke 是否稳定、finite、无 chi2 beta 后处理 |
| C3 small hidden 地球物理结果 | 15 | 低信噪比、薄层、负密度异常的小规模恢复能力 |
| C4 medium hidden 稳健结果 | 10 | 中等规模 low-SNR/negative density case 的稳定性 |
| C5 资源合规 | 2 | 是否无 timeout、无 error、无 NaN/inf |

### 5.1 C1 smoke test，4 分

| 指标 | 分数 | 满分行为 |
|---|---:|---|
| import 成功 | 1 | `DABIC_Beta_Estimator` 可导入 |
| 可实例化 | 1 | directive 构造函数不报错 |
| tiny hidden SimPEG case 跑通 | 1 | 能作为 directive 插入 `BaseInversion` |
| 无公开 shape 硬编码 | 1 | 不依赖公开数据的 `1271/1681/12000` 形状 |

地球物理解释：这一步只证明实现不是空壳，能够在一个小型 3D gravity problem 中进入反演循环。

### 5.2 C2 hidden smoke 运行质量，4 分

| 指标 | 分数 | 满分行为 |
|---|---:|---|
| L0/L1 smoke 都跑通 | 1 | 稀疏范数和平滑范数均可运行 |
| 关键指标 finite | 1 | `chi2_per_N`、`rmse_ratio`、`iou_vs_true` 无 NaN/inf |
| runtime 合规 | 1 | case < 45 s，单次 `endIter` < 10 s |
| 无 chi2 beta 后处理 | 1 | 不用 `target_misfit` / `discrepancy` 对 beta 事后修正 |

v3.4 中，C2 不再高权重评价数据空间、logdet、L0/L1 beta 响应。这些交由 E 负责，避免 C/E 重复。

### 5.3 C3 small hidden，15 分

三个小规模隐藏地质场景：

| 场景 | 地球物理含义 |
|---|---|
| `low_snr_small` | 低信噪比下恢复两个正密度异常体 |
| `thin_layer_small` | 浅部薄层 + 深部体，测试垂向分辨率 |
| `negative_small` | 负密度异常体，测试盐丘/低密度体类问题 |

每个场景跑 L0 和 L1，各 2.5 分：

| 指标 | 分数 | 满分行为 |
|---|---:|---|
| RMSE 相对 cooling | 1.0 | `RMSE_DABIC / RMSE_cooling < 0.8` |
| 支撑 IoU | 0.9 | `IoU >= 0.55` |
| `chi2_per_N` | 0.4 | 接近 1 |
| beta history | 0.2 | beta 有基本收敛轨迹 |

地球物理解释：C3 不要求每个 cell 的密度幅值完全正确，因为重力反演非唯一；它要求恢复体的大致位置、尺度、符号和数据拟合水平合理。

### 5.4 C4 medium hidden，10 分

两个中等规模隐藏场景：

| 场景 | norm | 分数 |
|---|---|---:|
| `low_snr_medium` | L1 | 5 |
| `negative_medium` | L0 | 5 |

每个 case：

| 指标 | 分数 | 满分行为 |
|---|---:|---|
| finite metrics | 1.0 | `chi2/RMSE/IoU` 全部 finite |
| RMSE 相对 cooling | 1.5 | D-ABIC 明显优于 cooling |
| 支撑 IoU | 1.5 | 异常体空间支撑合理 |
| `chi2_per_N` | 0.5 | 接近噪声水平 |
| runtime / no timeout | 0.5 | 中等规模 case 能稳定完成 |

地球物理解释：C4 是对稳定性的检验。一个实现如果只在 toy problem 上有效，但在 4480 cells / 500 data 的中等问题上崩溃，则不应获得较高 hidden 泛化分。

### 5.5 C5 资源合规，2 分

| 指标 | 分数 |
|---|---:|
| 所有 hidden case 无 timeout | 1 |
| 无 error 且成功 case 指标 finite | 1 |

C5 反映反演算法是否适合在评测环境中重复运行。地球物理反演中的矩阵病态和过大 determinant 计算常导致 timeout 或 NaN，因此资源合规是必要条件。

## 6. D：Vinton 实测，30 分

D 评价 agent 是否能把方法用于真实 Vinton dome 重力数据。L0、L1 各 15 分。

每个 norm：

| 指标 | 分数 | 评审解释 |
|---|---:|---|
| 残差 RMS 相对 Xu HMC | 4 | 数据拟合是否接近文献级参考 |
| cap rock center depth | 6 | 盖层/盐丘中心深度是否地质合理 |
| IoU vs Xu HMC body | 5 | 恢复体支撑是否接近参考结构 |

D 高分要求 agent 不只是合成数据好看，还能在实测重力异常上给出合理地下密度结构。

## 7. E：行为指纹，8 分

E 是 D-ABIC 机制正确性的主评项。

| 指标 | 分数含义 |
|---|---|
| 数据空间矩阵 | 捕获到主要 `n_data x n_data` 矩阵 |
| beta 真实更新 | beta 跨多个数量级变化 |
| 稳定 logdet | 使用 `cho_factor/slogdet/eigh/eigvalsh/svd` |
| 避免 bad det | 不使用 `np.linalg.det` |
| L0/L1 响应 | L0 和 L1 beta 序列有差异 |

E 的地球物理含义是：判断实现是否真的在做 D-ABIC evidence-based beta selection，而不是普通 inversion 加一个 beta history 字段。

## 8. F：报告，12 分

F 评价报告是否能以地球物理语言解释方法和结果。

报告应包含：

1. D-ABIC 方法说明。
2. 合成数据和 Vinton 数据结果。
3. beta 选择行为和与 cooling 的对比。
4. MT 到 gravity 的迁移讨论。
5. 结论、局限和未来工作。

F 不应替代数值结果，但可以区分“只提交代码”和“能解释地球物理意义”的解法。

## 9. 惩罚因子设计

### 9.1 公式

```text
final_score = raw_total * structural_penalty
```

其中：

```text
structural_penalty ∈ {1.00, 0.50, 0.34}
```

### 9.2 三档惩罚

| 条件 | penalty | 解释 |
|---|---:|---|
| 无 structural_failure | 1.00 | D-ABIC 机制基本正确，不惩罚 |
| 有 structural_failure，但 C/D/F 成熟 | 0.50 | 机制仍有缺陷，但 hidden、Vinton、报告已有实质证据 |
| 有 structural_failure，且 C/D/F 不成熟 | 0.34 | 浅层可运行，但核心结构问题未解决 |

成熟证据阈值：

```text
C_hidden >= 19.5
D_vinton >= 12.0
F_report >= 8.0
```

三项必须同时满足。

### 9.3 为什么需要全局惩罚

从地球物理角度，以下问题不是局部小错误，而是会影响整个反演结论可信度的结构性缺陷：

1. D-ABIC directive 没有真正接入 SimPEG inversion loop。
2. beta 不是 evidence-based，而是靠 chi-square target 后处理。
3. logdet 使用不稳定 determinant。
4. 只适配公开数据形状，不能迁移 hidden scenarios。
5. Vinton 结果依赖 decimation 或自造几何指标。

如果没有全局惩罚，agent 可能通过报告、公开合成结果或局部 hard-code 获得较高 raw_total，但其地球物理结论仍不可信。

### 9.4 0.34 是否合理

0.34 的作用是压制“浅层跑通但结构不成熟”的解法。

以 30min run 为例：

```text
raw_total = 43.8663
penalty = 0.34
final_score = 14.9146
```

30min agent 的特征是：

```text
C = 15.8 < 19.5
D = 8.0 < 12.0
F = 6.5 < 8.0
```

它能跑出一些结果，但 hidden 泛化、Vinton 实测和报告成熟度都不够。因此，把 43.9 的 raw_total 压到 15 以下是合理的。

从 benchmark 设计看，0.34 合理，因为它实现了：

```text
30min agent 不因浅层跑通而超过 15 分。
```

### 9.5 0.50 是否合理

0.50 的作用是保留“仍有结构问题，但已有较成熟地球物理证据”的解法。

以 2h run 为例：

```text
raw_total = 55.0305
penalty = 0.50
final_score = 27.5152
```

2h agent 的成熟证据：

```text
C = 19.9 >= 19.5
D = 13.9 >= 12.0
F = 8.2 >= 8.0
```

这说明它已经不只是 smoke pass，而是在 hidden、Vinton 和报告三方面都有实质提升。但因为 E 仍显示 structural_failure，所以不能给完整 raw_total。

从地球物理评审角度，0.50 是合理折中：

```text
承认 2h agent 的真实进步，但不把有机制缺陷的反演解释提升到高分区。
```

### 9.6 1.00 是否合理

如果没有 structural_failure，说明 agent 通过了核心机制检查：

```text
数据空间 D-ABIC
beta 真实更新
稳定 logdet
无 bad determinant
L0/L1 有不同响应
```

这种情况下不应再整体惩罚，应让 A/B/C/D/E/F 的 raw_total 自然决定分数。因此 1.00 合理。

## 10. 惩罚因子的风险

当前惩罚因子合理，但不是完美。

主要风险：

1. `{0.34, 0.50, 1.00}` 是离散档位，有跳变。
2. `C>=19.5, D>=12, F>=8` 是经验阈值，不是物理定律。
3. 阈值附近可能出现 raw_total 很接近、final_score 差异较大的情况。
4. 当前阈值由 30min/2h 两个样本校准，样本数量仍少。

更理想的长期方案是连续 maturity penalty，例如：

```text
maturity = weighted_score(C, D, F)
penalty = 0.34 + 0.16 * maturity
```

这样可以把 `0.34 -> 0.50` 的跳变变成连续过渡。

但在当前 benchmark 校准阶段，离散惩罚因子更容易解释，也更容易控制目标：

```text
30min <= 15
2h 有提升
2h <= 30
```

## 11. 总体判断

从地球物理学者视角，当前 v3.4 评分标准是合理的。

理由：

1. A/B/C/D/E/F 覆盖了代码结构、合成恢复、hidden 泛化、实测解释、机制指纹和报告论证。
2. C/E 去重后，C 更专注 hidden geophysical generalization，E 更专注 D-ABIC mechanism fingerprint。
3. 惩罚因子能阻止浅层可运行解法获得过高分数。
4. 2h agent 的真实改进被保留，但结构性缺陷仍受到限制。
5. 当前复评结果满足设计目标：

```text
30min = 14.9146
2h = 27.5152
```

因此，`0.34 / 0.50 / 1.00` 的惩罚因子在当前样本和任务目标下是合理的。

需要保留的说明是：它是 benchmark calibration penalty，不是地球物理反演理论中的唯一正确权重。若未来有更多 agent 样本，建议升级为连续 maturity penalty。
